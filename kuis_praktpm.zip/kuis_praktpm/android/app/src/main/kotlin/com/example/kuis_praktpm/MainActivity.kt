package com.example.kuis_praktpm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
