import 'package:flutter/material.dart';
import 'package:kuis_praktpm/rental_car.dart';

class HalamanDetail extends StatefulWidget {
  final RentalCar rental;
  const HalamanDetail({Key? key, required this.rental}) : super(key: key);

  @override
  State<HalamanDetail> createState() => _HalamanDetailState();
}

class _HalamanDetailState extends State<HalamanDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Align(
            alignment: Alignment.center,
            child: Text("${widget.rental.brand} ${widget.rental.model}"),
          ),
        ),
        body: SingleChildScrollView(
            child: Container(
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(4),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height/3,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemBuilder:
                            (context, index) =>
                            Image.network(widget.rental.images[index]),
                        itemCount: widget.rental.images.length,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "${widget.rental.brand} ${widget.rental.model}",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 24,
                      ),
                    ),
                    SizedBox(height: 15),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Column(
                        children: [
                          Text("Brand\t\t: ${widget.rental.brand}", textAlign: TextAlign.justify),
                          Text("Model\t\t: ${widget.rental.model}", textAlign: TextAlign.justify),
                          Text("Tahun\t\t: ${widget.rental.year}", textAlign: TextAlign.justify),
                          Text("Biaya Sewa\t: ${widget.rental.rentalPricePerDay} per Hari", textAlign: TextAlign.justify),
                          Text("Status\t: ", textAlign: TextAlign.justify),
                          widget.rental.available ? Text("Tersedia") : Text("Habis"),
                        ],
                      )
                    ),
                    SizedBox(height: 15),
                    ElevatedButton(onPressed: () {
                      setState(() {
                        widget.rental.available = false;
                      });
                    }, child: Text('Pesan')),
                    SizedBox(height: 15),
                    Text(
                      "Deskripsi",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(widget.rental.description),
                  ],
                )
            )
        )
    );
  }
}

