import 'package:flutter/material.dart';
import 'package:kuis_praktpm/rental_car.dart';
import 'halaman_detail.dart';

class HalamanUtama extends StatelessWidget {
  const HalamanUtama({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Align(
          alignment: Alignment.center,
          child: Text('Rental Mobil'),
        ),
      ),
      body: ListView.builder(
          itemCount: rentalCar.length,
          itemBuilder: (context, index) {
            final RentalCar rental = rentalCar[index];
            return Card(
              child: InkWell(
                onTap: () {
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context) => HalamanDetail(rental: rental))
                  );
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: Image.network(rental.images[1]),
                    ),
                    Expanded(
                      flex: 3,
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 25),
                            Text(
                              "${rental.brand} ${rental.model}",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 24,
                                fontStyle: FontStyle.italic,
                                ),
                              ),
                            SizedBox(height: 10),
                            Text(
                              "${rental.rentalPricePerDay} / hari",
                              style: TextStyle(color: Colors.black),
                            ),
                          ]
                        )
                      )
                    )
                  ]
                )
              )
            );
            /*return ListTile(
              onTap: () {},
              leading: Image.network(
                rental.images[1],
                width: 150,
                fit: BoxFit.cover,
              ),
              title: Text(rental.brand),
              subtitle: Text(rental.rentalPricePerDay),
            );*/
          }
      ),
    );
  }
}
