import 'package:flutter/material.dart';
import 'package:kuis_praktpm/halaman_utama.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis Prak TPM',
      theme: ThemeData(
        backgroundColor: Color(0xFF282828),
      ),
      debugShowCheckedModeBanner: false,
      home: HalamanUtama(),
    );
  }
}
